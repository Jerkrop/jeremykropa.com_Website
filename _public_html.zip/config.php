<?php

$conn = mysqli_connect('localhost','u828877760_Jerkrop12','Meegee12*','u828877760_user_db');

?>